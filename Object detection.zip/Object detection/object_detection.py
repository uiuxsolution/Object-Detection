import cv2
from ultralytics import YOLO
import numpy as np
import winsound
import time
from threading import Thread, Lock
import pyttsx3
import os

# Initialize a single TTS engine instance
engine = None
engine_lock = Lock()

def play_alarm():
    try:
        # Play a built-in Windows sound for reliability
        winsound.PlaySound('SystemHand', winsound.SND_ALIAS | winsound.SND_ASYNC)
    except Exception as e:
        print(f"Error playing alarm: {e}")

def get_engine():
    global engine
    if engine is None:
        try:
            engine = pyttsx3.init()
            engine.setProperty('rate', 150)
            engine.setProperty('volume', 0.9)
        except Exception as e:
            print(f"Error initializing TTS engine: {e}")
            return None
    return engine

def speak_object(text):
    try:
        engine = get_engine()
        if engine:
            with engine_lock:
                engine.say(text)
                engine.runAndWait()
    except Exception as e:
        print(f"Error in text-to-speech: {e}")

def speak_warning():
    try:
        engine = get_engine()
        if engine:
            with engine_lock:
                engine.say("INTRUDER DETECTED")
                engine.runAndWait()
    except Exception as e:
        print(f"Error in warning speech: {e}")

def main():
    # Initialize YOLOv8 model
    try:
        model = YOLO('yolov8n.pt')
    except Exception as e:
        print(f"Error loading YOLO model: {e}")
        return

    # Initialize webcam
    cap = cv2.VideoCapture(0)
    if not cap.isOpened():
        print("Error: Could not open webcam")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)
    cap.set(cv2.CAP_PROP_FPS, 30)

    # Initialize state variables
    last_alarm_time = 0
    last_announcement_time = 0
    alarm_cooldown = 3
    announcement_cooldown = 2
    frame_skip = 2
    frame_count = 0
    announced_objects = set()

    # Test TTS engine at startup
    speak_object("System initialized")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Failed to grab frame")
            break

        frame_count += 1
        if frame_count % frame_skip != 0:
            cv2.imshow('Object Detection', frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
            continue

        try:
            results = model(frame, conf=0.5, verbose=False)
            current_time = time.time()
            person_detected = False
            current_objects = set()

            for result in results:
                boxes = result.boxes
                for box in boxes:
                    class_id = int(box.cls[0])
                    conf = float(box.conf[0])
                    class_name = result.names[class_id]

                    if conf > 0.5:
                        current_objects.add(class_name)
                        if class_name == 'person':
                            person_detected = True

                    x1, y1, x2, y2 = map(int, box.xyxy[0].cpu().numpy())
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 255, 0), 2)
                    label = f'{class_name} {conf:.2f}'
                    cv2.putText(frame, label, (x1, y1 - 10),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

            # Handle object announcements
            if current_time - last_announcement_time >= announcement_cooldown:
                new_objects = current_objects - announced_objects
                for obj in new_objects:
                    if obj != 'person':
                        Thread(target=speak_object, args=(f"Detected {obj}",)).start()
                announced_objects = current_objects
                if new_objects:
                    last_announcement_time = current_time

            # Handle person detection
            if person_detected and (current_time - last_alarm_time) >= alarm_cooldown:
                Thread(target=play_alarm).start()
                Thread(target=speak_warning).start()
                last_alarm_time = current_time

        except Exception as e:
            print(f"Error processing frame: {e}")
            continue

        cv2.imshow('Object Detection', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == '__main__':
    main()